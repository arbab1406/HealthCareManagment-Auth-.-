﻿

namespace Healthcare.Domain.Entities;
public class Patient
{
    public int Id { get; set; }
    public string UserId { get; set; } = string.Empty; // Link to Identity User
    public DateTime DateOfBirth { get; set; }
    public string Gender { get; set; } = string.Empty;
    public string EmergencyContact { get; set; } = string.Empty;
    public string InsuranceInfo { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    // Navigation properties
    public User User { get; set; } = null!;
    public ICollection<Appointment> Appointments { get; set; } = new List<Appointment>();
}