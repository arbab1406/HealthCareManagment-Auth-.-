﻿using Healthcare.Application.Interfaces;
using Healthcare.Application.DTOs;
using Healthcare.Domain.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Healthcare.Infrastructure.Data;

namespace Healthcare.Application.Services;
public class DoctorService : IDoctorService
{
    private readonly ApplicationDbContext _context;
    private readonly UserManager<User> _userManager;

    public DoctorService(ApplicationDbContext context, UserManager<User> userManager)
    {
        _context = context;
        _userManager = userManager;
    }

    public async Task<IEnumerable<DoctorDto>> GetAllDoctorsAsync()
    {
        var doctors = await _context.Doctors
            .Include(d => d.User)
            .ToListAsync();

        return doctors.Select(d => new DoctorDto
        {
            Id = d.Id,
            UserId = d.UserId,
            FirstName = d.User.FirstName,
            LastName = d.User.LastName,
            Email = d.User.Email ?? "",
            PhoneNumber = d.User.PhoneNumber ?? "",
            Specialization = d.Specialization,
            LicenseNumber = d.LicenseNumber,
            Department = d.Department,
            IsAvailable = d.IsAvailable
        });
    }

    public async Task<DoctorDto> GetDoctorByIdAsync(int id)
    {
        var doctor = await _context.Doctors
            .Include(d => d.User)
            .FirstOrDefaultAsync(d => d.Id == id);

        if (doctor == null) throw new KeyNotFoundException("Doctor not found");

        return new DoctorDto
        {
            Id = doctor.Id,
            UserId = doctor.UserId,
            FirstName = doctor.User.FirstName,
            LastName = doctor.User.LastName,
            Email = doctor.User.Email ?? "",
            PhoneNumber = doctor.User.PhoneNumber ?? "",
            Specialization = doctor.Specialization,
            LicenseNumber = doctor.LicenseNumber,
            Department = doctor.Department,
            IsAvailable = doctor.IsAvailable
        };
    }

    public async Task<DoctorDto> CreateDoctorAsync(CreateDoctorDto doctorDto)
    {
        // Create User first
        var user = new User
        {
            FirstName = doctorDto.FirstName,
            LastName = doctorDto.LastName,
            UserName = doctorDto.Email,
            Email = doctorDto.Email,
            PhoneNumber = doctorDto.PhoneNumber,
            CreatedAt = DateTime.UtcNow
        };

        var userResult = await _userManager.CreateAsync(user, doctorDto.Password);
        if (!userResult.Succeeded)
        {
            throw new Exception(string.Join(", ", userResult.Errors.Select(e => e.Description)));
        }

        // Assign Doctor role
        await _userManager.AddToRoleAsync(user, "Doctor");

        // Create Doctor profile
        var doctor = new Doctor
        {
            UserId = user.Id,
            Specialization = doctorDto.Specialization,
            LicenseNumber = doctorDto.LicenseNumber,
            Department = doctorDto.Department,
            IsAvailable = true,
            CreatedAt = DateTime.UtcNow
        };

        _context.Doctors.Add(doctor);
        await _context.SaveChangesAsync();

        return new DoctorDto
        {
            Id = doctor.Id,
            UserId = doctor.UserId,
            FirstName = user.FirstName,
            LastName = user.LastName,
            Email = user.Email ?? "",
            PhoneNumber = user.PhoneNumber ?? "",
            Specialization = doctor.Specialization,
            LicenseNumber = doctor.LicenseNumber,
            Department = doctor.Department,
            IsAvailable = doctor.IsAvailable
        };
    }

    public async Task UpdateDoctorAsync(int id, UpdateDoctorDto doctorDto)
    {
        var doctor = await _context.Doctors.FindAsync(id);
        if (doctor == null) throw new KeyNotFoundException("Doctor not found");

        doctor.Specialization = doctorDto.Specialization;
        doctor.Department = doctorDto.Department;
        doctor.IsAvailable = doctorDto.IsAvailable;

        await _context.SaveChangesAsync();
    }

    public async Task DeleteDoctorAsync(int id)
    {
        var doctor = await _context.Doctors.FindAsync(id);
        if (doctor == null) throw new KeyNotFoundException("Doctor not found");

        _context.Doctors.Remove(doctor);
        await _context.SaveChangesAsync();

        // Also delete the user
        var user = await _userManager.FindByIdAsync(doctor.UserId);
        if (user != null)
        {
            await _userManager.DeleteAsync(user);
        }
    }

    public async Task<DoctorDto> GetDoctorByUserIdAsync(string userId)
    {
        var doctor = await _context.Doctors
            .Include(d => d.User)
            .FirstOrDefaultAsync(d => d.UserId == userId);

        if (doctor == null) throw new KeyNotFoundException("Doctor not found");

        return new DoctorDto
        {
            Id = doctor.Id,
            UserId = doctor.UserId,
            FirstName = doctor.User.FirstName,
            LastName = doctor.User.LastName,
            Email = doctor.User.Email ?? "",
            PhoneNumber = doctor.User.PhoneNumber ?? "",
            Specialization = doctor.Specialization,
            LicenseNumber = doctor.LicenseNumber,
            Department = doctor.Department,
            IsAvailable = doctor.IsAvailable
        };
    }
}