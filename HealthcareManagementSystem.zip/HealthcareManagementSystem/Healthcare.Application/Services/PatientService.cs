﻿using Healthcare.Application.Interfaces;
using Healthcare.Application.DTOs;
using Healthcare.Domain.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Healthcare.Infrastructure.Data;

namespace Healthcare.Application.Services;
public class PatientService : IPatientService
{
    private readonly ApplicationDbContext _context;
    private readonly UserManager<User> _userManager;

    public PatientService(ApplicationDbContext context, UserManager<User> userManager)
    {
        _context = context;
        _userManager = userManager;
    }

    public async Task<IEnumerable<PatientDto>> GetAllPatientsAsync()
    {
        var patients = await _context.Patients
            .Include(p => p.User)
            .ToListAsync();

        return patients.Select(p => new PatientDto
        {
            Id = p.Id,
            UserId = p.UserId,
            FirstName = p.User.FirstName,
            LastName = p.User.LastName,
            Email = p.User.Email ?? "",
            PhoneNumber = p.User.PhoneNumber ?? "",
            DateOfBirth = p.DateOfBirth,
            Gender = p.Gender,
            EmergencyContact = p.EmergencyContact,
            InsuranceInfo = p.InsuranceInfo
        });
    }

    public async Task<PatientDto> GetPatientByIdAsync(int id)
    {
        var patient = await _context.Patients
            .Include(p => p.User)
            .FirstOrDefaultAsync(p => p.Id == id);

        if (patient == null) throw new KeyNotFoundException("Patient not found");

        return new PatientDto
        {
            Id = patient.Id,
            UserId = patient.UserId,
            FirstName = patient.User.FirstName,
            LastName = patient.User.LastName,
            Email = patient.User.Email ?? "",
            PhoneNumber = patient.User.PhoneNumber ?? "",
            DateOfBirth = patient.DateOfBirth,
            Gender = patient.Gender,
            EmergencyContact = patient.EmergencyContact,
            InsuranceInfo = patient.InsuranceInfo
        };
    }

    public async Task<PatientDto> CreatePatientAsync(CreatePatientDto patientDto)
    {
        // Create User first
        var user = new User
        {
            FirstName = patientDto.FirstName,
            LastName = patientDto.LastName,
            UserName = patientDto.Email,
            Email = patientDto.Email,
            PhoneNumber = patientDto.PhoneNumber,
            CreatedAt = DateTime.UtcNow
        };

        var userResult = await _userManager.CreateAsync(user, patientDto.Password);
        if (!userResult.Succeeded)
        {
            throw new Exception(string.Join(", ", userResult.Errors.Select(e => e.Description)));
        }

        // Assign Patient role
        await _userManager.AddToRoleAsync(user, "Patient");

        // Create Patient profile
        var patient = new Patient
        {
            UserId = user.Id,
            DateOfBirth = patientDto.DateOfBirth,
            Gender = patientDto.Gender,
            EmergencyContact = patientDto.EmergencyContact,
            InsuranceInfo = patientDto.InsuranceInfo,
            CreatedAt = DateTime.UtcNow
        };

        _context.Patients.Add(patient);
        await _context.SaveChangesAsync();

        return new PatientDto
        {
            Id = patient.Id,
            UserId = patient.UserId,
            FirstName = user.FirstName,
            LastName = user.LastName,
            Email = user.Email ?? "",
            PhoneNumber = user.PhoneNumber ?? "",
            DateOfBirth = patient.DateOfBirth,
            Gender = patient.Gender,
            EmergencyContact = patient.EmergencyContact,
            InsuranceInfo = patient.InsuranceInfo
        };
    }

    public async Task UpdatePatientAsync(int id, UpdatePatientDto patientDto)
    {
        var patient = await _context.Patients
            .Include(p => p.User)
            .FirstOrDefaultAsync(p => p.Id == id);

        if (patient == null) throw new KeyNotFoundException("Patient not found");

        // Update user properties
        if (patient.User != null)
        {
            patient.User.PhoneNumber = patientDto.PhoneNumber;
        }

        // Update patient properties
        patient.EmergencyContact = patientDto.EmergencyContact;
        patient.InsuranceInfo = patientDto.InsuranceInfo;

        await _context.SaveChangesAsync();
    }

    public async Task DeletePatientAsync(int id)
    {
        var patient = await _context.Patients.FindAsync(id);
        if (patient == null) throw new KeyNotFoundException("Patient not found");

        _context.Patients.Remove(patient);
        await _context.SaveChangesAsync();

        // Also delete the user
        var user = await _userManager.FindByIdAsync(patient.UserId);
        if (user != null)
        {
            await _userManager.DeleteAsync(user);
        }
    }

    public async Task<PatientDto> GetPatientByUserIdAsync(string userId)
    {
        var patient = await _context.Patients
            .Include(p => p.User)
            .FirstOrDefaultAsync(p => p.UserId == userId);

        if (patient == null) throw new KeyNotFoundException("Patient not found");

        return new PatientDto
        {
            Id = patient.Id,
            UserId = patient.UserId,
            FirstName = patient.User.FirstName,
            LastName = patient.User.LastName,
            Email = patient.User.Email ?? "",
            PhoneNumber = patient.User.PhoneNumber ?? "",
            DateOfBirth = patient.DateOfBirth,
            Gender = patient.Gender,
            EmergencyContact = patient.EmergencyContact,
            InsuranceInfo = patient.InsuranceInfo
        };
    }
}