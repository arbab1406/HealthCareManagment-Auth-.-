﻿using Healthcare.Application.DTOs;
using Healthcare.Application.Interfaces;
using Healthcare.Domain.Entities;
using Healthcare.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Healthcare.Application.Services;
public class AppointmentService : IAppointmentService
{
    private readonly ApplicationDbContext _context;

    public AppointmentService(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<AppointmentDto>> GetAllAppointmentsAsync()
    {
        var appointments = await _context.Appointments
            .Include(a => a.Patient)
                .ThenInclude(p => p.User)
            .Include(a => a.Doctor)
                .ThenInclude(d => d.User)
            .ToListAsync();

        return appointments.Select(a => new AppointmentDto
        {
            Id = a.Id,
            PatientId = a.PatientId,
            DoctorId = a.DoctorId,
            PatientName = $"{a.Patient.User.FirstName} {a.Patient.User.LastName}",
            DoctorName = $"{a.Doctor.User.FirstName} {a.Doctor.User.LastName}",
            AppointmentDate = a.AppointmentDate,
            Reason = a.Reason,
            Notes = a.Notes,
            Status = a.Status.ToString(),
            CreatedAt = a.CreatedAt
        });
    }

    public async Task<AppointmentDto> GetAppointmentByIdAsync(int id)
    {
        var appointment = await _context.Appointments
            .Include(a => a.Patient)
                .ThenInclude(p => p.User)
            .Include(a => a.Doctor)
                .ThenInclude(d => d.User)
            .FirstOrDefaultAsync(a => a.Id == id);

        if (appointment == null) throw new KeyNotFoundException("Appointment not found");

        return new AppointmentDto
        {
            Id = appointment.Id,
            PatientId = appointment.PatientId,
            DoctorId = appointment.DoctorId,
            PatientName = $"{appointment.Patient.User.FirstName} {appointment.Patient.User.LastName}",
            DoctorName = $"{appointment.Doctor.User.FirstName} {appointment.Doctor.User.LastName}",
            AppointmentDate = appointment.AppointmentDate,
            Reason = appointment.Reason,
            Notes = appointment.Notes,
            Status = appointment.Status.ToString(),
            CreatedAt = appointment.CreatedAt
        };
    }

    public async Task<AppointmentDto> CreateAppointmentAsync(CreateAppointmentDto appointmentDto)
    {
        // Check if patient exists
        var patient = await _context.Patients.FindAsync(appointmentDto.PatientId);
        if (patient == null) throw new Exception("Patient not found");

        // Check if doctor exists
        var doctor = await _context.Doctors.FindAsync(appointmentDto.DoctorId);
        if (doctor == null) throw new Exception("Doctor not found");

        var appointment = new Appointment
        {
            PatientId = appointmentDto.PatientId,
            DoctorId = appointmentDto.DoctorId,
            AppointmentDate = appointmentDto.AppointmentDate,
            Reason = appointmentDto.Reason,
            Notes = appointmentDto.Notes,
            Status = Domain.enumss.AppointmentStatus.Scheduled,
            CreatedAt = DateTime.UtcNow
        };

        _context.Appointments.Add(appointment);
        await _context.SaveChangesAsync();

        // Reload with includes to return complete data
        return await GetAppointmentByIdAsync(appointment.Id);
    }

    public async Task UpdateAppointmentStatusAsync(int id, UpdateAppointmentStatusDto statusDto)
    {
        var appointment = await _context.Appointments.FindAsync(id);
        if (appointment == null) throw new KeyNotFoundException("Appointment not found");

        if (Enum.TryParse<Domain.enumss.AppointmentStatus>(statusDto.Status, out var status))
        {
            appointment.Status = status;
            await _context.SaveChangesAsync();
        }
        else
        {
            throw new Exception("Invalid appointment status");
        }
    }

    public async Task<IEnumerable<AppointmentDto>> GetAppointmentsByPatientAsync(int patientId)
    {
        var appointments = await _context.Appointments
            .Include(a => a.Patient)
                .ThenInclude(p => p.User)
            .Include(a => a.Doctor)
                .ThenInclude(d => d.User)
            .Where(a => a.PatientId == patientId)
            .ToListAsync();

        return appointments.Select(a => new AppointmentDto
        {
            Id = a.Id,
            PatientId = a.PatientId,
            DoctorId = a.DoctorId,
            PatientName = $"{a.Patient.User.FirstName} {a.Patient.User.LastName}",
            DoctorName = $"{a.Doctor.User.FirstName} {a.Doctor.User.LastName}",
            AppointmentDate = a.AppointmentDate,
            Reason = a.Reason,
            Notes = a.Notes,
            Status = a.Status.ToString(),
            CreatedAt = a.CreatedAt
        });
    }

    public async Task<IEnumerable<AppointmentDto>> GetAppointmentsByDoctorAsync(int doctorId)
    {
        var appointments = await _context.Appointments
            .Include(a => a.Patient)
                .ThenInclude(p => p.User)
            .Include(a => a.Doctor)
                .ThenInclude(d => d.User)
            .Where(a => a.DoctorId == doctorId)
            .ToListAsync();

        return appointments.Select(a => new AppointmentDto
        {
            Id = a.Id,
            PatientId = a.PatientId,
            DoctorId = a.DoctorId,
            PatientName = $"{a.Patient.User.FirstName} {a.Patient.User.LastName}",
            DoctorName = $"{a.Doctor.User.FirstName} {a.Doctor.User.LastName}",
            AppointmentDate = a.AppointmentDate,
            Reason = a.Reason,
            Notes = a.Notes,
            Status = a.Status.ToString(),
            CreatedAt = a.CreatedAt
        });
    }
}