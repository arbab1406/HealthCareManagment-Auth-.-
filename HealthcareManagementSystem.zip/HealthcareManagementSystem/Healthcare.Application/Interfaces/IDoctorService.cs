﻿using Healthcare.Application.DTOs;

namespace Healthcare.Application.Interfaces;
public interface IDoctorService
{
    Task<IEnumerable<DoctorDto>> GetAllDoctorsAsync();
    Task<DoctorDto> GetDoctorByIdAsync(int id);
    Task<DoctorDto> CreateDoctorAsync(CreateDoctorDto doctorDto);
    Task UpdateDoctorAsync(int id, UpdateDoctorDto doctorDto);
    Task DeleteDoctorAsync(int id);
    Task<DoctorDto> GetDoctorByUserIdAsync(string userId);
}