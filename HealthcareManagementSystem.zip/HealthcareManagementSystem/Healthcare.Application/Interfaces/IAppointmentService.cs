﻿using Healthcare.Application.DTOs;

namespace Healthcare.Application.Interfaces;
public interface IAppointmentService
{
    Task<IEnumerable<AppointmentDto>> GetAllAppointmentsAsync();
    Task<AppointmentDto> GetAppointmentByIdAsync(int id);
    Task<AppointmentDto> CreateAppointmentAsync(CreateAppointmentDto appointmentDto);
    Task UpdateAppointmentStatusAsync(int id, UpdateAppointmentStatusDto statusDto); // This should return Task (void)
    Task<IEnumerable<AppointmentDto>> GetAppointmentsByPatientAsync(int patientId);
    Task<IEnumerable<AppointmentDto>> GetAppointmentsByDoctorAsync(int doctorId);
}