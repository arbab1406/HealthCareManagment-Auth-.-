﻿using Healthcare.Application.DTOs;

namespace Healthcare.Application.Interfaces
{
    public interface IAuthService
    {
        // Existing methods
        Task<AuthResponseDto> RegisterAsync(RegisterDto registerDto);
        Task<AuthResponseDto> LoginAsync(LoginDto loginDto);
        Task<bool> AssignRoleAsync(string email, string role);
        Task<ProfileDto> GetUserProfileAsync(string userId);

        // New methods
        Task<ProfileDto> UpdateProfileAsync(string userId, UpdateProfileDto updateDto);
        Task<bool> ChangePasswordAsync(string userId, ChangePasswordDto changePasswordDto);
        Task<IEnumerable<UserListDto>> GetAllUsersAsync();
        Task<UserListDto> GetUserByIdAsync(string userId);
        Task<bool> UpdateUserAsync(string userId, UpdateUserDto updateDto);
        Task<bool> DeleteUserAsync(string userId);
    }
}