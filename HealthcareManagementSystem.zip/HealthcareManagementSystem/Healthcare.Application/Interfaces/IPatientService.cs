﻿using Healthcare.Application.DTOs;

namespace Healthcare.Application.Interfaces;
public interface IPatientService
{
    Task<IEnumerable<PatientDto>> GetAllPatientsAsync();
    Task<PatientDto> GetPatientByIdAsync(int id);
    Task<PatientDto> CreatePatientAsync(CreatePatientDto patientDto);
    Task UpdatePatientAsync(int id, UpdatePatientDto patientDto);
    Task DeletePatientAsync(int id);
    Task<PatientDto> GetPatientByUserIdAsync(string userId);
}